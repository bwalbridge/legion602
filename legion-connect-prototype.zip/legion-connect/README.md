# Legion Connect — Interactive MVP Prototype

A self-contained, mobile-responsive **demonstration** for a multi-tenant American Legion Family community platform.

## Try it

Open `index.html` in a modern browser. No installation, account, server, or external services are required.

## Included

- Two fictional demonstration tenants (Post 602 and Post 101) with separated local datasets.
- Public-facing preview and member view.
- Home feed and post announcements.
- Group chat channels and browser-local messages.
- Events with RSVPs and volunteer signups.
- Photo gallery placeholders.
- Polls with one vote per demo user per poll.
- Sample member directory and Legion/SAL/Auxiliary group structure.
- Post-admin demo: approve fictional members, publish announcements, add events, polls, albums.
- Platform-admin role preview and tenant switcher.
- Responsive layouts for phone and desktop.
- Browser localStorage persistence and reset button.

## Important limitations

This is a **prototype, not a deployed service**. No real login, member verification, cross-device synchronization, push notifications, actual media upload, email, secure server-side access control, billing, or live chat. The demo role switcher is deliberately unrestricted. Browser localStorage is **not** suitable for private member data. The example names and activities are fictional, and no American Legion endorsement is implied.

## Production build recommendations

1. React/TypeScript frontend with accessible component library and PWA shell.
2. Managed PostgreSQL/Supabase backend with **server-enforced** tenant isolation and row-level security.
3. Auth with verified email, invitation workflows, membership approval and optional MFA for administrators.
4. Model `users`, `organizations`, `posts`, `memberships`, `roles`, `groups`, `channels`, `messages`, `events`, `rsvps`, `polls`, `votes`, `albums`, `media`, `audit_events` with explicit ownership and access policies.
5. Cross-post access by explicit membership or invitations; do not treat a tenant switcher as authorization.
6. Private media buckets with signed URLs, moderation/consent controls, storage quotas and retention rules.
7. Rate limiting, backups, security logging, accessibility testing, privacy/terms and incident-response procedures.
8. Only after security review: pilot with a small verified group at Post 602.

## Validation checklist

- Change post selector: tenant-specific feed, chat, calendar, poll, and directory change.
- Switch to public view: chat/admin/private directory hidden; only public events appear.
- Switch to Post Admin: create an event, poll, album and announcement; approve a sample request.
- Send a message and vote in a poll; refresh browser to confirm demo persistence.
- Test narrow/mobile viewport and keyboard navigation.

All sample content is illustrative, not verified Post 602 information.

## Branding update (October 2026)
- Added original Legion Connect prototype icon in `assets/legion-connect-mark.svg` and patriotic hero artwork in `assets/patriotic-banner.svg`.
- These original graphics are **not** The American Legion official emblem or brandmark.
- The official American Legion brandmark is recommended for digital marketing, but the Legion, SAL and Auxiliary marks are protected. Before using them in a multi-tenant third-party application, obtain the applicable permissions and use only unchanged official artwork: https://www.legion.org/about/media-toolkits/brand-marks-guidelines
- Once authorization and approved files are available, replace the prototype mark in the header or add the official marks in post-specific areas without modifying the supplied artwork.
